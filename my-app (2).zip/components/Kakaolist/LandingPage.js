import React, { useState } from "react";
import { Map, MapMarker, ZoomControl } from "react-kakao-maps-sdk";
import dynamic from "next/dynamic";
import axios from "axios";
import Styles from "../../styles/Kakaoa.module.css";
import { MagnifyingGlassIcon } from "@heroicons/react/20/solid";

function LandingPage() {
  const DynamicComponen = dynamic(() => import("./MapContainer"), {
    ssr: false,
  });

  const [InputText, setInputText] = useState("");
  const [Place, setPlace] = useState("");

  const onChange = (e) => {
    setInputText(e.target.value);
  };

  const handleSubmit = (e) => {
    e.preventDefault();
    setPlace(InputText);
    setInputText("");
  };

  return (
    <>
      <div className={Styles.test}>
        <MagnifyingGlassIcon className="mr-2 h-5 w-5" />
        <form className={Styles.inputForm} onSubmit={handleSubmit}>
          <input
            placeholder="검색어를 입력하세요"
            onChange={onChange}
            value={InputText}
          />
          <button type="submit"></button>
        </form>
        <DynamicComponen searchPlace={Place} />
      </div>
    </>
  );
}

export default LandingPage;
