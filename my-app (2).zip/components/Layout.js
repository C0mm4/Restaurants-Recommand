import Head from "next/head";
import Styles from "../styles/Layout.module.css";
import { ToastContainer } from "react-toastify";
import "react-toastify/dist/ReactToastify.css";
import { signOut, useSession } from "next-auth/react";
import { Menu } from "@headlessui/react";
import Cookies from "js-cookie";

export default function Layout({ title, children }) {
  const { status, data: session } = useSession();

  const logoutClickHandler = () => {
    Cookies.remove("cart");
    signOut({ callbackUrl: "/signin" });
  };

  return (
    <>
      <Head>
        <title>{title ? title + " - 8F CAPSTION" : "8F CAPSTION"}</title>
        <meta name="description" content="Nextjs" />
        <link
          rel="icon"
          href="/festival_decoration_party_celebration_holiday_flag_carnival_icon_150775.ico"
        />
      </Head>

      <ToastContainer position="bottom-center" limit={1} />

      <div className={Styles.bar}>
        <header>
          <nav className={Styles.nava}>
            <div className={Styles.aaa}>
              <div className={Styles.gitimgbox}>
                <img className={Styles.gitimg} src="images/logo.png"></img>
              </div>

              <div>
                <a href="/">8F CAPSTION</a>
                <textarea
                  className={Styles.textt}
                  placeholder="원하시는 가게 이름으 적어주세여"
                ></textarea>
              </div>
            </div>
            <div className={Styles.bbb}>
              <a href="/" className="p-2">
                공지사항
              </a>
              <a href="/" className="p-2">
                축재소개
              </a>
              <a href="/" className="p-2">
                커뮤니티
              </a>
              <a href="/" className="p-2">
                개발자 연결
              </a>
            </div>
          </nav>
        </header>
      </div>

      <main className="container m-auto mt-4">{children}</main>

      <br />
      <footer className="flex h-10 justify-center items-center shadow-inner bg-green-200">
        <p className={Styles.footer}>Copyright &copy; 8F capston</p>
      </footer>
    </>
  );
}
