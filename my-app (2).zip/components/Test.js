import Styles from "../styles/intro.module.css";
import Layout from "../components/Layout";
import Kakao_intro from "../components/Kakao_intro";
import Season from "../components/season";
import Tr from "../components/Tr";
import { Tab } from "@headlessui/react";
import Post from "../components/Post";
import Modal from "../components/Modal";
import React, { useEffect, useState, useRef } from "react";
import axios from "axios";

const eatlist = () => {
  const [info, setInfo] = useState([]);
  const [selected, setSelected] = useState("");
  const [modalOn, setModalOn] = useState(false);

  const nextid = useRef(11);

  useEffect(() => {
    axios
      .get("http://localhost:4000/")
      .Post("http://localhost:3000/data")
      .then((res) => setInfo(res.data))
      .catch((err) => console.log(err));
  }, []);

  const handleSave = (data) => {
    if (data.id) {
      setInfo(
        info.map((row) =>
          data.id === row.id
            ? {
                id: data.id,
                category: data.category,
                address: data.address,
                name: data.name,
                placeurl: data.placeurl,
                roadaddress: data.roadaddress,
                x: data.x,
                y: data.y,
              }
            : row
        )
      );
    } else {
      setInfo((info) =>
        info.concat({
          id: nextid.current,
          category: data.category,
          address: data.address,
          name: data.name,
          placeurl: data.placeurl,
          roadaddress: data.roadaddress,
          x: data.x,
          y: data.y,
        })
      );
      nextid.current += 1;
    }
  };

  const handleRemove = (id) => {
    setInfo((info) => info.filter((item) => item.id !== id));
  };

  const handleEdit = (item) => {
    setModalOn(true);
    const selectedData = {
      id: item.id,
      category: data.category,
      address: data.address,
      name: data.name,
      placeurl: data.placeurl,
      roadaddress: data.roadaddress,
      x: data.x,
      y: data.y,
    };
    console.log(selectedData);
    setSelected(selectedData);
  };

  const handleCancel = () => {
    setModalOn(false);
  };

  const handleEditSubmit = (item) => {
    console.log(item);
    handleSave(item);
    setModalOn(false);
  };

  const [isCheck, setCheck] = useState(true);

  return (
    <div className={Styles.btnroom}>
      <div className={Styles.btnn}>
        <button
          className={Styles.btn}
          onClick={() => {
            // setCheck로 state값을 변경해주자.
            // e로 상태값을 받아왔다. 클릭시 상태값은 !상태값이므로 값이 반전된다 false -> true
            setCheck((e) => !e);
          }}
        >
          {isCheck ? "보지않기" : "정보보기"}
        </button>
      </div>

      {isCheck && (
        <div className={Styles.board}>
          <table className="min-w-full table-auto text-gray-800 ">
            <thead className="justify-between">
              <tr className="bg-gray-800 opacity-80">
                <th className="text-gray-300 px-4 py-3">No</th>
                <th className="text-gray-300 px-4 py-3">카테고리</th>
                <th className="text-gray-300 px-4 py-3">주소</th>
                <th className="text-gray-300 px-4 py-3">이름</th>
                <th className="text-gray-300 px-4 py-3">주소링크</th>
                <th className="text-gray-300 px-4 py-3">도로명</th>
                <th className="text-gray-300 px-4 py-3">x</th>
                <th className="text-gray-300 px-4 py-3">y</th>
                <th className="text-gray-300 px-4 py-3">Edit</th>
                <th className="text-gray-300 px-4 py-3">Delete</th>
              </tr>
            </thead>
            <Tr
              info={info}
              handleRemove={handleRemove}
              handleEdit={handleEdit}
            />
          </table>
        </div>
      )}

      <Post onSaveData={handleSave} />
      {modalOn && (
        <Modal
          selectedData={selected}
          handleCancel={handleCancel}
          handleEditSubmit={handleEditSubmit}
        />
      )}
    </div>
  );
};

export default eatlist;
