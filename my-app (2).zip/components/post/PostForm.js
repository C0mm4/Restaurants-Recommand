import React, { useState } from "react";
import axios from "axios";

function Postform() {
  const baseurl = "http://128.134.131.31:5000/test";
  const [data, setData] = useState({
    keyword: "",

    gangnam: "강남",
    gangdong: "강동",
    gangbuk: "강북",
    gangseo: "강서",
    gwanak: "관악",
    gwangjin: "광진",
    guro: "구로",
    geumcheon: "금촌",
    nowon: "노원",
    dobong: "도봉",
    dongdaemun: "동대문",
    dongjak: "동작",
    mapo: "마포",
    seodaemun: "서대문",
    seopo: "서초",
    seongdong: "성동",
    seongbuk: "성북",
    songpa: "송파",
    yangcheon: "양천",
    yeongdeungpo: "영등포",
    yongsan: "용산",
    eunpyeong: "은평",
    jongno: "종로",
    jung: "중",
    jungnang: "중랑",

    gu: "",
  });
  const [url,setUrl] = useState(baseurl)

  async function submit(e) {
    e.preventDefault();
    console.log(region.data)
    await axios
      .get(url,{
        params :{
          keyword : data.keyword,
          gu : region.value,
        }
      })
      .then((res => {
        console.log(url)
        console.log(res.data)
      }))
      .catch(function (error){
        console.log(error.request)
      });
  }

  function handle(e) {
    const newdata = { ...data };
    newdata[e.target.id] = e.target.value;
    setData(newdata);
    console.log(region.value);
    ("");
  }

  return (
    <div>
      <div value={data.index} />
      <form onSubmit={(e) => submit(e)}>
        <input
          onChange={(e) => handle(e)}
          id="keyword"
          value={data.keyword}
          placeholder="keyword"
          type="text"
        ></input>

        <div> </div>
        <select id="region">
          <option disabled selected>
            지역을 선택해주세요
          </option>
          <option value={data.gangnam}>강남구</option>
          <option value={data.gangdong}>강동구</option>
          <option value={data.gangbuk}>강북구</option>
          <option value={data.gangseo}>강서구</option>
          <option value={data.gwanak}>관악구</option>
          <option value={data.gwangjin}>광진구</option>
          <option value={data.guro}>구로구</option>
          <option value={data.geumcheon}>금천구</option>
          <option value={data.nowon}>노원구</option>
          <option value={data.dobong}>도봉구</option>
          <option value={data.dongdaemun}>동대문구</option>
          <option value={data.dongjak}>동작구</option>
          <option value={data.mapo}>마포구</option>
          <option value={data.seodaemun}>서대문구</option>
          <option value={data.seopo}>서포구</option>
          <option value={data.seongdong}>성동구</option>
          <option value={data.seongbuk}>성북구</option>
          <option value={data.songpa}>송파구</option>
          <option value={data.yangcheon}>양천구</option>
          <option value={data.yeongdeungpo}>영등포구</option>
          <option value={data.yongsan}>용산구</option>
          <option value={data.eunpyeong}>은평구</option>
          <option value={data.jongno}>종로구</option>
          <option value={data.jung}>중구</option>
          <option value={data.jungnang}>중랑구</option>
        </select>
        <button>Submit</button>
      </form>
    </div>
  );
}

export default Postform;