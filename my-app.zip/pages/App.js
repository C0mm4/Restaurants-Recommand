import PostForm from "../components/post/PostForm";
import UsePropsBoolean from "../components/boolean/UsePropsBoolean"
import React, { Component } from 'react';






function App() {
  return (
    <div className="App">
      <PostForm />
    </div>
  );
}

export default App;
