import React from "react";

export default function ad() {
  function homzzang() {
    window.location.href = "http://localhost:3000/data";
  }

  return (
    <div>
      <button
        onclick={homzzang()}
        /* className="bg-blue-400 py-2 text-center px-10 md:px-12 md:py-3 text-white
rounded text-xl md:text-base mt-4"
            type="submit"*/
      >
        저장
      </button>
    </div>
  );
}
