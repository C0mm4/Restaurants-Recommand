import Layout from "../components/Layout";
import Styles from "../styles/Home.module.css";
import Slider from "react-slick";
import Kakao from "../components/Kakao";

export default function Home() {
  const settings = {
    arrows: true,
    dots: true,
    infinite: true,
    speed: 500,
    slidesToShow: 1,
    slidesToScroll: 1,
    autoplay: true,
    autoplaySpeed: 3000,
  };

  return (
    <Layout title="Home">
      {/* 슬라이드 */}

      <div className={Styles.slidecenter}>
        <div className={Styles.slidemain}>
          <div className={Styles.slide}>
            <Slider {...settings}>
              <div className={Styles.slideimgbox}>
                <h3>
                  <img className={Styles.slideimg} src="images/han.jpg"></img>
                </h3>
                <figure className={Styles.fig}>
                  <figcaption>한식</figcaption>
                </figure>
              </div>
              <div className={Styles.slideimgbox}>
                <h3>
                  <img className={Styles.slideimg} src="images/jpa.jpg"></img>
                </h3>
                <figure className={Styles.fig}>
                  <figcaption>일식</figcaption>
                </figure>
              </div>
              <div className={Styles.slideimgbox}>
                <h3>
                  <img className={Styles.slideimg} src="images/chi.jpg"></img>
                </h3>
                <figure className={Styles.fig}>
                  <figcaption>중식</figcaption>
                </figure>
              </div>
              <div className={Styles.slideimgbox}>
                <h3>
                  <img className={Styles.slideimg} src="images/wes.jpg"></img>
                </h3>
                <figure className={Styles.fig}>
                  <figcaption>양식</figcaption>
                </figure>
              </div>
              <div className={Styles.slideimgbox}>
                <h3>
                  <img
                    className={Styles.slideimg}
                    src="images/chiken.jpg"
                  ></img>
                </h3>
                <figure className={Styles.fig}>
                  <figcaption>치킨</figcaption>
                </figure>
              </div>
              <div className={Styles.slideimgbox}>
                <h3>
                  <img className={Styles.slideimg} src="images/snack.jpg"></img>
                </h3>
                <figure className={Styles.fig}>
                  <figcaption>분식</figcaption>
                </figure>
              </div>
            </Slider>
          </div>
        </div>
      </div>

      {/* 한국 지도 */}
      <Kakao></Kakao>
    </Layout>
  );
}
