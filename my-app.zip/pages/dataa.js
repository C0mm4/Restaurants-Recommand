import React from 'react'

export default function ad() {
 
    const frm = new FormData()
    frm.append('resion', '지역')
    frm.append('keyword', '키워드')
    
    axios.post('http://localhost:3000/dataa', frm)
    .then((res) => {
        console.log(res.data);
      });
 
    return (
    <div>

        
    </div>
  )
}