import React, { useState } from "react";
import axios from "axios";

function Postform() {
  const baseurl = "http://localhost:5000/test";
  const [data, setData] = useState({
    keyword: "",

    gangnam: "Gangnam",
    gangdong: "Gangdong",
    gangbuk: "Gangbuk",
    gangseo: "Gangseo",
    gwanak: "Gwanak",
    gwangjin: "Gwangjin",
    guro: "Guro",
    geumcheon: "Geumcheon",
    nowon: "Nowon",
    dobong: "Dobong",
    dongdaemun: "Dongdaemun",
    dongjak: "Dongjak",
    mapo: "Mapo",
    seodaemun: "Seodaemun",
    seopo: "Seopo",
    seongdong: "Seongdong",
    seongbuk: "Seongbuk",
    songpa: "Songpa",
    yangcheon: "Yangcheon",
    yeongdeungpo: "Yeongdeungpo",
    yongsan: "Yongsan",
    eunpyeong: "Eunpyeong",
    jongno: "Jongno",
    jung: "Jung",
    jungnang: "Jungnang",

    gu: "",
  });
  const [url,setUrl] = useState(baseurl)

  async function submit(e) {
    e.preventDefault();
    setUrl(baseurl + '?keyword=' + data.keyword + '&gu=' + region.value)
    
    await axios
      .get(url,{

      })
      .then((res => {
        console.log(url)
        console.log(res.data)
      }));
    //   .post(url, {
    //     keyword: data.keyword,
    //     index: data.index,
    //     gu: region.value,
    //   })
    //   .then((res) => {
    //     console.log(res.data);
    //   });
  }

  function handle(e) {
    const newdata = { ...data };
    newdata[e.target.id] = e.target.value;
    setData(newdata);
    console.log(newdata);
    ("");
  }

  return (
    <div>
      <div value={data.index} />
      <form onSubmit={(e) => submit(e)}>
        <input
          onChange={(e) => handle(e)}
          id="keyword"
          value={data.keyword}
          placeholder="keyword"
          type="text"
        ></input>

        <div> </div>
        <select id="region">
          <option disabled selected>
            지역을 선택해주세요
          </option>
          <option value={data.gangnam}>강남구</option>
          <option value={data.gangdong}>강동구</option>
          <option value={data.gangbuk}>강북구</option>
          <option value={data.gangseo}>강서구</option>
          <option value={data.gwanak}>관악구</option>
          <option value={data.gwangjin}>광진구</option>
          <option value={data.guro}>구로구</option>
          <option value={data.geumcheon}>금천구</option>
          <option value={data.nowon}>노원구</option>
          <option value={data.dobong}>도봉구</option>
          <option value={data.dongdaemun}>동대문구</option>
          <option value={data.dongjak}>동작구</option>
          <option value={data.mapo}>마포구</option>
          <option value={data.seodaemun}>서대문구</option>
          <option value={data.seopo}>서포구</option>
          <option value={data.seongdong}>성동구</option>
          <option value={data.seongbuk}>성북구</option>
          <option value={data.songpa}>송파구</option>
          <option value={data.yangcheon}>양천구</option>
          <option value={data.yeongdeungpo}>영등포구</option>
          <option value={data.yongsan}>용산구</option>
          <option value={data.eunpyeong}>은평구</option>
          <option value={data.jongno}>종로구</option>
          <option value={data.jung}>중구</option>
          <option value={data.jungnang}>중랑구</option>
        </select>
        <button>Submit</button>
      </form>
    </div>
  );
}

export default Postform;